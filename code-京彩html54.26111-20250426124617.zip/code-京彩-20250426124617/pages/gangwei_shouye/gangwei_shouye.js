function onClick() {
  location.href = '../../pages/gangweixiangqingye/gangweixiangqingye.html';
}

function onClick_1() {
  location.href = '../../pages/jianli/jianli.html';
}

function onClick_2() {
  location.href = '../../pages/mianshi/mianshi.html';
}

function onClick_3() {
  location.href = '../../pages/geren/geren.html';
}