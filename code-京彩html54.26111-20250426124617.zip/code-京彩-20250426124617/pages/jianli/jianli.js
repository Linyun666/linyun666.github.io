function onClick() {
  location.href = '../../pages/gangwei_shouye/gangwei_shouye.html';
}

function onClick_1() {
  location.href = '../../pages/mianshi/mianshi.html';
}

function onClick_2() {
  location.href = '../../pages/geren/geren.html';
}